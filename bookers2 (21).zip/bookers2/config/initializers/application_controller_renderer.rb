# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'eb2d144ab60f600a9e310f9897aac208cd7e9165b1088288fb3b96c36e838cc065d7a4c812d612bb340f97e6fde9f09d9af34e9784c2e4ccdb8cbe276b8a1432'